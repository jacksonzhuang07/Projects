by Jianhao Zhuang
Assignment 1 Bank program

Source files:
Account.cc
Bank.cc
CustArray.cc
Customer.cc
Main.cc

Header Files:
Account.h
Bank.h
CustArray.h
Customer.h

Compile using make command. Launch using ./A1 in terminal.
